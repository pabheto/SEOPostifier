<?php
/**
 * View Script Template - Simplified to show only settings
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Get interview ID from URL parameter
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET parameter for navigation, not form processing
$autoblogger_interview_id = isset($_GET['interviewId']) ? sanitize_text_field(wp_unslash($_GET['interviewId'])) : '';

if (empty($autoblogger_interview_id)) {
    echo '<div class="notice notice-error"><p>' . esc_html(__('No interview ID provided.', 'autoblogger')) . '</p></div>';
    return;
}
?>

<div class="autoblogger-view-script">
    <div class="card">
        <h2><?php esc_html_e('Draft Settings', 'autoblogger'); ?></h2>
        
        <p>
            <a href="?page=autoblogger&tab=scripts" class="button button-secondary">
                <?php esc_html_e('← Back to My Drafts', 'autoblogger'); ?>
            </a>
            <button type="button" id="create-wp-draft-btn" class="button button-primary" style="display: none; margin-left: 10px;">
                <?php esc_html_e('Create WordPress Draft', 'autoblogger'); ?>
            </button>
        </p>

        <div id="loading-interview" style="margin: 20px 0;">
            <p><?php esc_html_e('Loading draft data...', 'autoblogger'); ?></p>
        </div>

        <div id="interview-container" style="display: none; margin-top: 20px;">
            <!-- Tab Navigation -->
            <div class="autoblogger-form-tabs">
                <button type="button" class="form-tab active" data-tab="draft">
                    <?php esc_html_e('Draft Information', 'autoblogger'); ?>
                </button>
                <button type="button" class="form-tab" data-tab="settings">
                    <?php esc_html_e('Settings', 'autoblogger'); ?>
                </button>
            </div>

            <!-- Edit Form -->
            <form id="edit-interview-form" style="margin-top: 20px;">
                
                <!-- Tab 1: Draft Information -->
                <div id="tab-draft" class="form-tab-content active">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="edit-main-keyword"><?php esc_html_e('Search Intent', 'autoblogger'); ?> *</label>
                            </th>
                            <td>
                                <input type="text" id="edit-main-keyword" name="mainKeyword" class="regular-text" required />
                                <p class="description"><?php esc_html_e('Primary keyword or search intent to optimize for', 'autoblogger'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="edit-user-description"><?php esc_html_e('Post Description', 'autoblogger'); ?></label>
                            </th>
                            <td>
                                <textarea id="edit-user-description" name="userDescription" rows="6"
                                          class="large-text"></textarea>
                                <p class="description"><?php esc_html_e('Optional: Describe what the post should be about', 'autoblogger'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Tab 2: Settings -->
                <div id="tab-settings" class="form-tab-content">
                    <h3><?php esc_html_e('Advanced Settings', 'autoblogger'); ?></h3>
                    <p class="description"><?php esc_html_e('Configure additional settings for your draft. Click on each section to expand.', 'autoblogger'); ?></p>

                    <!-- Accordion: Images -->
                    <div class="settings-accordion">
                        <div class="accordion-header">
                            <h4><?php esc_html_e('Images', 'autoblogger'); ?></h4>
                            <span class="accordion-toggle">▼</span>
                        </div>
                        <div class="accordion-content">
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="edit-ai-images-mode"><?php esc_html_e('AI Images', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <select id="edit-ai-images-mode" name="aiImagesMode">
                                            <option value="disabled"><?php esc_html_e('Disabled', 'autoblogger'); ?></option>
                                            <option value="auto" selected><?php esc_html_e('Auto', 'autoblogger'); ?></option>
                                            <option value="custom"><?php esc_html_e('Custom', 'autoblogger'); ?></option>
                                        </select>
                                        <p class="description"><?php esc_html_e('Select how AI images should be generated', 'autoblogger'); ?></p>
                                    </td>
                                </tr>
                                <tr id="edit-ai-images-custom-count-row" style="display: none;">
                                    <th scope="row">
                                        <label for="edit-ai-images-count"><?php esc_html_e('Number of Images', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <input type="number" id="edit-ai-images-count" name="aiImagesCount"
                                               value="5" min="1" class="small-text" />
                                        <p class="description"><?php esc_html_e('Number of AI-generated images to create', 'autoblogger'); ?></p>
                                    </td>
                                </tr>
                                <tr id="edit-ai-images-custom-descriptions-row" style="display: none;">
                                    <th scope="row">
                                        <label for="edit-use-custom-ai-descriptions"><?php esc_html_e('Custom AI Descriptions', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <input type="checkbox" id="edit-use-custom-ai-descriptions" name="useCustomAiDescriptions" value="1" />
                                        <label for="edit-use-custom-ai-descriptions"><?php esc_html_e('Provide custom descriptions for each AI image', 'autoblogger'); ?></label>
                                    </td>
                                </tr>
                                <tr id="edit-ai-images-descriptions-container" style="display: none;">
                                    <td colspan="2">
                                        <div id="edit-ai-images-descriptions-list"></div>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label><?php esc_html_e('User Images', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <button type="button" id="edit-add-user-image" class="button button-secondary">
                                            <?php esc_html_e('+ Add User Image', 'autoblogger'); ?>
                                        </button>
                                        <p class="description"><?php esc_html_e('Add your own images to be used in the post', 'autoblogger'); ?></p>
                                        <div id="edit-user-images-list" style="margin-top: 15px;"></div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Accordion: Style and Audience -->
                    <div class="settings-accordion">
                        <div class="accordion-header">
                            <h4><?php esc_html_e('Style and Audience', 'autoblogger'); ?></h4>
                            <span class="accordion-toggle">▼</span>
                        </div>
                        <div class="accordion-content">
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="edit-language"><?php esc_html_e('Language', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <select id="edit-language" name="language">
                                            <option value="en">English</option>
                                            <option value="es" selected>Español</option>
                                            <option value="fr">Français</option>
                                            <option value="de">Deutsch</option>
                                            <option value="it">Italiano</option>
                                            <option value="pt">Português</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="edit-search-intent"><?php esc_html_e('Search Intent Type', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <select id="edit-search-intent" name="searchIntent">
                                            <option value="informational" selected>Informational</option>
                                            <option value="transactional">Transactional</option>
                                            <option value="commercial">Commercial</option>
                                            <option value="navigational">Navigational</option>
                                        </select>
                                        <p class="description"><?php esc_html_e('User\'s search intent type', 'autoblogger'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="edit-target-audience"><?php esc_html_e('Target Audience', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" id="edit-target-audience" name="targetAudience"
                                               class="regular-text" value="General audience" />
                                        <p class="description"><?php esc_html_e('Describe your target audience', 'autoblogger'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="edit-tone-of-voice"><?php esc_html_e('Tone of Voice', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <select id="edit-tone-of-voice" name="toneOfVoice">
                                            <option value="professional">Professional</option>
                                            <option value="friendly" selected>Friendly</option>
                                            <option value="technical">Technical</option>
                                            <option value="educational">Educational</option>
                                            <option value="casual">Casual</option>
                                            <option value="formal">Formal</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="edit-min-word-count"><?php esc_html_e('Minimum Word Count', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <input type="number" id="edit-min-word-count" name="minWordCount"
                                               value="2000" min="100" class="small-text" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="edit-max-word-count"><?php esc_html_e('Maximum Word Count', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <input type="number" id="edit-max-word-count" name="maxWordCount"
                                               value="2500" min="100" class="small-text" />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="edit-needs-faq"><?php esc_html_e('Include FAQ Section', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <input type="checkbox" id="edit-needs-faq" name="needsFaqSection" value="1" checked />
                                        <label for="edit-needs-faq"><?php esc_html_e('Add FAQ section at the end', 'autoblogger'); ?></label>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="edit-notes-for-writer"><?php esc_html_e('Additional Instructions', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <textarea id="edit-notes-for-writer" name="notesForWriter" rows="3"
                                                  class="large-text"></textarea>
                                        <p class="description"><?php esc_html_e('Any additional instructions or requirements', 'autoblogger'); ?></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Accordion: Keywords -->
                    <div class="settings-accordion">
                        <div class="accordion-header">
                            <h4><?php esc_html_e('Keywords', 'autoblogger'); ?></h4>
                            <span class="accordion-toggle">▼</span>
                        </div>
                        <div class="accordion-content">
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="edit-secondary-keywords"><?php esc_html_e('Secondary Keywords', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" id="edit-secondary-keywords" name="secondaryKeywords" class="large-text" />
                                        <p class="description"><?php esc_html_e('Comma-separated list of secondary keywords', 'autoblogger'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="edit-keyword-density"><?php esc_html_e('Keyword Density Target', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <input type="number" id="edit-keyword-density" name="keywordDensityTarget"
                                               value="0.015" min="0" max="1" step="0.001" class="small-text" />
                                        <p class="description"><?php esc_html_e('Target keyword density (0-1, default: 0.015)', 'autoblogger'); ?></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Accordion: Link Mentions -->
                    <div class="settings-accordion">
                        <div class="accordion-header">
                            <h4><?php esc_html_e('Link Mentions', 'autoblogger'); ?></h4>
                            <span class="accordion-toggle">▼</span>
                        </div>
                        <div class="accordion-content">
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="edit-internal-links-mode"><?php esc_html_e('Internal Links', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <select id="edit-internal-links-mode" name="internalLinksMode">
                                            <option value="auto" selected><?php esc_html_e('Auto', 'autoblogger'); ?></option>
                                            <option value="disabled"><?php esc_html_e('Disabled', 'autoblogger'); ?></option>
                                            <option value="custom"><?php esc_html_e('Custom', 'autoblogger'); ?></option>
                                        </select>
                                        <p class="description"><?php esc_html_e('Select how internal links should be handled', 'autoblogger'); ?></p>
                                    </td>
                                </tr>
                                <tr class="edit-internal-links-custom-fields" style="display: none;">
                                    <th scope="row">
                                        <label for="edit-internal-links-to-use"><?php esc_html_e('Internal Links URLs', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <textarea id="edit-internal-links-to-use" name="internalLinksToUse" rows="3"
                                                  class="large-text" placeholder="One URL per line"></textarea>
                                        <p class="description"><?php esc_html_e('Specific internal links to include (one per line)', 'autoblogger'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="edit-external-links-research-mode"><?php esc_html_e('External Link Research', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <select id="edit-external-links-research-mode" name="externalLinksResearchMode">
                                            <option value="auto" selected><?php esc_html_e('Auto', 'autoblogger'); ?></option>
                                            <option value="disabled"><?php esc_html_e('Disabled', 'autoblogger'); ?></option>
                                        </select>
                                        <p class="description"><?php esc_html_e('Automatically research and include external links', 'autoblogger'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="edit-use-custom-external-links"><?php esc_html_e('Use Custom External Links', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <input type="checkbox" id="edit-use-custom-external-links"
                                               name="useCustomExternalLinks" value="1" />
                                        <label for="edit-use-custom-external-links"><?php esc_html_e('Provide specific external links to include', 'autoblogger'); ?></label>
                                    </td>
                                </tr>
                                <tr class="edit-external-links-custom-fields" style="display: none;">
                                    <th scope="row">
                                        <label for="edit-external-links-to-use"><?php esc_html_e('External Links URLs', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <textarea id="edit-external-links-to-use" name="externalLinksToUse" rows="3"
                                                  class="large-text" placeholder="One URL per line"></textarea>
                                        <p class="description"><?php esc_html_e('Specific external links to include (one per line)', 'autoblogger'); ?></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Accordion: Brand Mentions -->
                    <div class="settings-accordion">
                        <div class="accordion-header">
                            <h4><?php esc_html_e('Brand Mentions', 'autoblogger'); ?></h4>
                            <span class="accordion-toggle">▼</span>
                        </div>
                        <div class="accordion-content">
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="edit-mentions-brand"><?php esc_html_e('Mention Brand', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <input type="checkbox" id="edit-mentions-brand" name="mentionsBrand" value="1" />
                                        <label for="edit-mentions-brand"><?php esc_html_e('Include brand mentions', 'autoblogger'); ?></label>
                                    </td>
                                </tr>
                                <tr class="edit-brand-fields" style="display: none;">
                                    <th scope="row">
                                        <label for="edit-brand-name"><?php esc_html_e('Brand Name', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" id="edit-brand-name" name="brandName" class="regular-text" />
                                    </td>
                                </tr>
                                <tr class="edit-brand-fields" style="display: none;">
                                    <th scope="row">
                                        <label for="edit-brand-description"><?php esc_html_e('Brand Description', 'autoblogger'); ?></label>
                                    </th>
                                    <td>
                                        <textarea id="edit-brand-description" name="brandDescription" rows="2"
                                                  class="large-text"></textarea>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

                <p class="submit" style="margin-top: 20px;">
                    <button type="submit" id="update-settings-btn" class="button button-primary button-large">
                        <?php esc_html_e('Update Settings & Re-create Post', 'autoblogger'); ?>
                    </button>
                </p>
                <div id="update-status" style="margin-top: 15px;"></div>
            </form>
        </div>

        <div id="interview-error" style="display: none; margin-top: 20px;">
            <!-- Error messages will appear here -->
        </div>
    </div>
</div>

<script type="text/javascript">
jQuery(document).ready(function($) {
    'use strict';

    const interviewId = '<?php echo esc_js($autoblogger_interview_id); ?>';
    const $loading = $('#loading-interview');
    const $container = $('#interview-container');
    const $error = $('#interview-error');
    
    let currentInterview = null;

    // Tab switching
    $('.form-tab').on('click', function() {
        const tab = $(this).data('tab');
        $('.form-tab').removeClass('active');
        $(this).addClass('active');
        $('.form-tab-content').removeClass('active');
        $('#tab-' + tab).addClass('active');
    });

    // Accordion functionality
    $('.accordion-header').on('click', function() {
        const $accordion = $(this).closest('.settings-accordion');
        const $content = $accordion.find('.accordion-content');
        const $toggle = $(this).find('.accordion-toggle');
        
        $accordion.toggleClass('active');
        $content.slideToggle(200);
        $toggle.toggleClass('expanded');
    });

    // Initialize accordions - all closed by default
    $('.accordion-content').hide();
    $('.accordion-toggle').addClass('expanded');

    // Toggle conditional fields
    $('#edit-mentions-brand').on('change', function() {
        if ($(this).is(':checked')) {
            $('.edit-brand-fields').show();
        } else {
            $('.edit-brand-fields').hide();
        }
    });
    
    // Handle AI images mode change
    $('#edit-ai-images-mode').on('change', function() {
        const mode = $(this).val();
        if (mode === 'custom') {
            $('#edit-ai-images-custom-count-row').show();
            $('#edit-ai-images-count').trigger('change');
        } else {
            $('#edit-ai-images-custom-count-row').hide();
            $('#edit-ai-images-custom-descriptions-row').hide();
            $('#edit-use-custom-ai-descriptions').prop('checked', false);
            $('#edit-ai-images-descriptions-container').hide();
        }
    });

    // Handle AI images count change (only when in custom mode)
    $('#edit-ai-images-count').on('change', function() {
        if ($('#edit-ai-images-mode').val() !== 'custom') {
            return;
        }
        editAiImagesCount = parseInt($(this).val()) || 5;
        if (editAiImagesCount > 1) {
            $('#edit-ai-images-custom-descriptions-row').show();
        } else {
            $('#edit-ai-images-custom-descriptions-row').hide();
            $('#edit-use-custom-ai-descriptions').prop('checked', false);
            $('#edit-ai-images-descriptions-container').hide();
        }
        updateEditAiDescriptionsList();
    });

    // Handle internal links mode change
    $('#edit-internal-links-mode').on('change', function() {
        const mode = $(this).val();
        if (mode === 'custom') {
            $('.edit-internal-links-custom-fields').show();
        } else {
            $('.edit-internal-links-custom-fields').hide();
        }
    });

    // Handle external links research mode change
    $('#edit-external-links-research-mode').on('change', function() {
        // Mode change doesn't affect custom links checkbox
    });

    // Toggle custom external links fields
    $('#edit-use-custom-external-links').on('change', function() {
        if ($(this).is(':checked')) {
            $('.edit-external-links-custom-fields').show();
        } else {
            $('.edit-external-links-custom-fields').hide();
        }
    });

    // Image configuration handlers
    let editUserImageCounter = 0;
    let editAiImagesCount = 5;

    // Handle custom AI descriptions checkbox
    $('#edit-use-custom-ai-descriptions').on('change', function() {
        if ($(this).is(':checked')) {
            $('#edit-ai-images-descriptions-container').show();
            updateEditAiDescriptionsList();
        } else {
            $('#edit-ai-images-descriptions-container').hide();
        }
    });

    // Update AI descriptions list
    function updateEditAiDescriptionsList() {
        const container = $('#edit-ai-images-descriptions-list');
        container.empty();
        
        if (! $('#edit-use-custom-ai-descriptions').is(':checked')) {
            return;
        }

        const count = parseInt($('#edit-ai-images-count').val()) || 5;
        for (let i = 0; i < count; i++) {
            const item = $('<div class="ai-image-description-item" style="margin-bottom: 15px; padding: 15px; border: 1px solid #ddd; border-radius: 4px; background: #f9f9f9;"></div>');
            item.append('<label style="display: block; font-weight: 600; margin-bottom: 5px;">' + 
                '<?php esc_html_e('Image', 'autoblogger'); ?> ' + (i + 1) + ':</label>');
            item.append('<textarea class="large-text edit-ai-image-description" data-index="' + i + '" ' +
                'placeholder="<?php esc_html_e('Describe what this image should show...', 'autoblogger'); ?>" ' +
                'rows="2" style="width: 100%;"></textarea>');
            container.append(item);
        }
    }

    // Add user image
    $('#edit-add-user-image').on('click', function() {
        const imageId = 'edit-user-image-' + editUserImageCounter++;
        const item = $('<div class="edit-user-image-item" data-id="' + imageId + '" style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 4px; background: #f9f9f9;"></div>');
        
        item.append('<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">' +
            '<strong><?php esc_html_e('User Image', 'autoblogger'); ?> #' + (editUserImageCounter) + '</strong>' +
            '<button type="button" class="button button-link-delete edit-remove-user-image" style="color: #b32d2e;">' +
            '<?php esc_html_e('Remove', 'autoblogger'); ?></button></div>');
        
        item.append('<table class="form-table" style="margin: 0;"><tbody>');
        
        // Source Type
        item.find('tbody').append('<tr>' +
            '<th style="width: 150px; padding: 10px 0;"><label><?php esc_html_e('Source Type', 'autoblogger'); ?></label></th>' +
            '<td style="padding: 10px 0;"><input type="text" class="regular-text edit-user-image-source-type" ' +
            'placeholder="<?php esc_html_e('e.g., url, wordpress_id', 'autoblogger'); ?>" /></td>' +
            '</tr>');
        
        // Source Value (Link)
        item.find('tbody').append('<tr>' +
            '<th style="width: 150px; padding: 10px 0;"><label><?php esc_html_e('Link/URL', 'autoblogger'); ?> *</label></th>' +
            '<td style="padding: 10px 0;"><input type="text" class="regular-text edit-user-image-source-value" ' +
            'placeholder="<?php esc_html_e('Image URL or WordPress ID', 'autoblogger'); ?>" required /></td>' +
            '</tr>');
        
        // Suggested Alt
        item.find('tbody').append('<tr>' +
            '<th style="width: 150px; padding: 10px 0;"><label><?php esc_html_e('Alt Text', 'autoblogger'); ?></label></th>' +
            '<td style="padding: 10px 0;"><input type="text" class="regular-text edit-user-image-alt" ' +
            'placeholder="<?php esc_html_e('Suggested alt text for the image', 'autoblogger'); ?>" /></td>' +
            '</tr>');
        
        // Image Description
        item.find('tbody').append('<tr>' +
            '<th style="width: 150px; padding: 10px 0;"><label><?php esc_html_e('Image Description', 'autoblogger'); ?></label></th>' +
            '<td style="padding: 10px 0;"><textarea class="large-text edit-user-image-description" rows="2" ' +
            'placeholder="<?php esc_html_e('Describe the image and what it shows', 'autoblogger'); ?>"></textarea></td>' +
            '</tr>');
        
        // Usage Notes
        item.find('tbody').append('<tr>' +
            '<th style="width: 150px; padding: 10px 0;"><label><?php esc_html_e('Usage Notes', 'autoblogger'); ?></label></th>' +
            '<td style="padding: 10px 0;"><textarea class="large-text edit-user-image-notes" rows="2" ' +
            'placeholder="<?php esc_html_e('How should this image be used in the post?', 'autoblogger'); ?>"></textarea></td>' +
            '</tr>');
        
        item.find('tbody').append('</tbody></table>');
        
        $('#edit-user-images-list').append(item);
        
        // Remove button handler
        item.find('.edit-remove-user-image').on('click', function() {
            item.remove();
        });
    });

    // Initialize AI images mode handler
    $('#edit-ai-images-mode').trigger('change');

    // Populate edit form with interview data
    function populateEditForm(interview) {
        $('#edit-main-keyword').val(interview.mainKeyword || '');
        $('#edit-secondary-keywords').val(Array.isArray(interview.secondaryKeywords) ? interview.secondaryKeywords.join(', ') : '');
        $('#edit-keyword-density').val(interview.keywordDensityTarget || 0.015);
        $('#edit-user-description').val(interview.userDescription || '');
        $('#edit-language').val(interview.language || 'es');
        $('#edit-search-intent').val(interview.searchIntent || 'informational');
        $('#edit-target-audience').val(interview.targetAudience || 'General audience');
        $('#edit-tone-of-voice').val(interview.toneOfVoice || 'friendly');
        $('#edit-min-word-count').val(interview.minWordCount || '2000');
        $('#edit-max-word-count').val(interview.maxWordCount || '2500');
        $('#edit-needs-faq').prop('checked', interview.needsFaqSection !== false);
        $('#edit-mentions-brand').prop('checked', interview.mentionsBrand === true);
        $('#edit-brand-name').val(interview.brandName || '');
        $('#edit-brand-description').val(interview.brandDescription || '');
        
        // Handle internal links mode
        if (interview.internalLinksMode) {
            $('#edit-internal-links-mode').val(interview.internalLinksMode);
        } else if (interview.includeInternalLinks === false) {
            $('#edit-internal-links-mode').val('disabled');
        } else if (interview.includeInternalLinksAutomatically === true) {
            $('#edit-internal-links-mode').val('auto');
        } else if (interview.internalLinksToUse && interview.internalLinksToUse.length > 0) {
            $('#edit-internal-links-mode').val('custom');
        } else {
            $('#edit-internal-links-mode').val('auto');
        }
        $('#edit-internal-links-mode').trigger('change');
        $('#edit-internal-links-to-use').val(Array.isArray(interview.internalLinksToUse) ? interview.internalLinksToUse.join('\n') : '');
        
        // Handle external links research mode
        if (interview.externalLinksResearchMode) {
            $('#edit-external-links-research-mode').val(interview.externalLinksResearchMode);
        } else if (interview.externalLinksToIncludeAutomatically === -1 || interview.includeExternalLinks === true) {
            $('#edit-external-links-research-mode').val('auto');
        } else {
            $('#edit-external-links-research-mode').val('disabled');
        }
        
        // Handle custom external links
        if (interview.useCustomExternalLinks || (interview.externalLinksToUse && interview.externalLinksToUse.length > 0)) {
            $('#edit-use-custom-external-links').prop('checked', true);
            $('#edit-use-custom-external-links').trigger('change');
        }
        $('#edit-external-links-to-use').val(Array.isArray(interview.externalLinksToUse) ? interview.externalLinksToUse.join('\n') : '');
        $('#edit-notes-for-writer').val(interview.notesForWriter || '');
        
        // Populate image configuration
        const imagesConfig = interview.imagesConfig || {};
        const aiImagesCount = imagesConfig.aiImagesCount || -1;
        
        if (aiImagesCount === -1) {
            $('#edit-ai-images-mode').val('auto');
        } else if (aiImagesCount === 0) {
            $('#edit-ai-images-mode').val('disabled');
        } else {
            $('#edit-ai-images-mode').val('custom');
            $('#edit-ai-images-count').val(aiImagesCount);
        }
        $('#edit-ai-images-mode').trigger('change');
        
        if (imagesConfig.useCustomAiDescriptions && imagesConfig.aiImagesUserDescriptions) {
            $('#edit-use-custom-ai-descriptions').prop('checked', true);
            $('#edit-use-custom-ai-descriptions').trigger('change');
            setTimeout(function() {
                imagesConfig.aiImagesUserDescriptions.forEach(function(desc, index) {
                    $('.edit-ai-image-description[data-index="' + index + '"]').val(desc || '');
                });
            }, 100);
        }
        
        // Populate user images
        $('#edit-user-images-list').empty();
        editUserImageCounter = 0;
        if (imagesConfig.useUserImages && Array.isArray(imagesConfig.userImages)) {
            imagesConfig.userImages.forEach(function(userImage) {
                if (userImage.sourceValue) {
                    $('#edit-add-user-image').trigger('click');
                    const $lastItem = $('#edit-user-images-list .edit-user-image-item').last();
                    $lastItem.find('.edit-user-image-source-type').val(userImage.sourceType || '');
                    $lastItem.find('.edit-user-image-source-value').val(userImage.sourceValue || '');
                    $lastItem.find('.edit-user-image-alt').val(userImage.suggestedAlt || '');
                    if (userImage.notes) {
                        const notesParts = userImage.notes.split('\n\nUsage: ');
                        $lastItem.find('.edit-user-image-description').val(notesParts[0] || '');
                        if (notesParts[1]) {
                            $lastItem.find('.edit-user-image-notes').val(notesParts[1] || '');
                        }
                    }
                }
            });
        }
        
        // Toggle conditional fields
        $('.edit-brand-fields').toggle($('#edit-mentions-brand').is(':checked'));
    }

    // Helper function to split string into array
    const splitAndFilter = (str, delimiter) => {
        if (!str || typeof str !== 'string') return [];
        return str.split(delimiter)
            .map(item => item.trim())
            .filter(item => item.length > 0);
    };

    // Update settings form submission
    $('#edit-interview-form').on('submit', function(e) {
        e.preventDefault();
        
        const $status = $('#update-status');
        const $button = $('#update-settings-btn');
        const originalText = $button.text();
        
        $button.prop('disabled', true).text('<?php esc_html_e('Updating...', 'autoblogger'); ?>');
        $status.html('');

        // Collect images configuration
        const aiImagesMode = $('#edit-ai-images-mode').val();
        let aiImagesCount;
        
        if (aiImagesMode === 'auto') {
            aiImagesCount = -1;
        } else if (aiImagesMode === 'custom') {
            const aiImagesCountInput = $('#edit-ai-images-count').val();
            aiImagesCount = (aiImagesCountInput !== '' && !isNaN(parseInt(aiImagesCountInput))) 
                ? parseInt(aiImagesCountInput) 
                : 5;
        } else {
            // disabled
            aiImagesCount = 0;
        }
        
        const useCustomAiDescriptions = $('#edit-use-custom-ai-descriptions').is(':checked');
        const aiImagesUserDescriptions = [];
        
        if (useCustomAiDescriptions && aiImagesMode === 'custom' && aiImagesCount > 0) {
            $('.edit-ai-image-description').each(function() {
                const desc = $(this).val().trim();
                if (desc) {
                    aiImagesUserDescriptions.push(desc);
                }
            });
        }
        
        const userImages = [];
        $('.edit-user-image-item').each(function() {
            const $item = $(this);
            const sourceValue = $item.find('.edit-user-image-source-value').val().trim();
            
            if (sourceValue) {
                const imageDescription = $item.find('.edit-user-image-description').val().trim();
                const usageNotes = $item.find('.edit-user-image-notes').val().trim();
                
                let notes = '';
                if (imageDescription) {
                    notes = imageDescription;
                }
                if (usageNotes) {
                    notes += (notes ? '\n\n' : '') + 'Usage: ' + usageNotes;
                }
                
                userImages.push({
                    sourceType: $item.find('.edit-user-image-source-type').val().trim() || 'url',
                    sourceValue: sourceValue,
                    suggestedAlt: $item.find('.edit-user-image-alt').val().trim() || undefined,
                    notes: notes || undefined
                });
            }
        });
        
        // Build images config object
        const imagesConfig = {
            aiImagesCount: aiImagesCount
        };
        
        if (aiImagesUserDescriptions.length > 0) {
            imagesConfig.aiImagesUserDescriptions = aiImagesUserDescriptions;
        }
        if (userImages.length > 0) {
            imagesConfig.useUserImages = true;
            imagesConfig.userImages = userImages;
        }

        const internalLinksMode = $('#edit-internal-links-mode').val();
        const formData = {
            interviewId: interviewId,
            mainKeyword: $('#edit-main-keyword').val(),
            secondaryKeywords: splitAndFilter($('#edit-secondary-keywords').val(), ','),
            keywordDensityTarget: parseFloat($('#edit-keyword-density').val()) || undefined,
            userDescription: $('#edit-user-description').val(),
            language: $('#edit-language').val(),
            searchIntent: $('#edit-search-intent').val(),
            targetAudience: $('#edit-target-audience').val(),
            toneOfVoice: $('#edit-tone-of-voice').val(),
            minWordCount: $('#edit-min-word-count').val() ? parseInt($('#edit-min-word-count').val()) : undefined,
            maxWordCount: $('#edit-max-word-count').val() ? parseInt($('#edit-max-word-count').val()) : undefined,
            needsFaqSection: $('#edit-needs-faq').is(':checked'),
            mentionsBrand: $('#edit-mentions-brand').is(':checked'),
            brandName: $('#edit-brand-name').val() || undefined,
            brandDescription: $('#edit-brand-description').val() || undefined,
            internalLinksMode: internalLinksMode,
            internalLinksToUse: internalLinksMode === 'custom' ? splitAndFilter($('#edit-internal-links-to-use').val(), '\n') : undefined,
            includeInternalLinks: internalLinksMode !== 'disabled',
            includeInternalLinksAutomatically: internalLinksMode === 'auto',
            externalLinksResearchMode: $('#edit-external-links-research-mode').val(),
            externalLinksToIncludeAutomatically: $('#edit-external-links-research-mode').val() === 'auto' ? -1 : undefined,
            useCustomExternalLinks: $('#edit-use-custom-external-links').is(':checked'),
            externalLinksToUse: $('#edit-use-custom-external-links').is(':checked') ? splitAndFilter($('#edit-external-links-to-use').val(), '\n') : undefined,
            notesForWriter: $('#edit-notes-for-writer').val() || undefined,
            imagesConfig: imagesConfig
        };

        Object.keys(formData).forEach(key => {
            if (formData[key] === undefined) {
                delete formData[key];
            }
        });

        // If internal links mode is auto, fetch blog links
        if (internalLinksMode === 'auto') {
            $.ajax({
                url: autobloggerData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'autoblogger_get_blog_links',
                    nonce: autobloggerData.nonce
                },
                success: function(linksResponse) {
                    if (linksResponse.success && linksResponse.data.formatted) {
                        formData.blogInternalLinksMeta = linksResponse.data.formatted;
                    }
                    submitUpdate();
                },
                error: function() {
                    // Continue without blog links if fetch fails
                    submitUpdate();
                }
            });
        } else {
            submitUpdate();
        }

        function submitUpdate() {
        $.ajax({
            url: autobloggerData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'autoblogger_update_interview',
                nonce: autobloggerData.nonce,
                interview_data: formData
            },
            success: function(response) {
                if (response.success) {
                    currentInterview = response.data.interview;
                    $status.html('<div class="notice notice-info inline"><p><?php esc_html_e('Settings updated. Starting generation...', 'autoblogger'); ?></p></div>');
                    $button.text('<?php esc_html_e('Starting Generation...', 'autoblogger'); ?>');
                    
                    // Start the new generation process
                    $.ajax({
                        url: autobloggerData.ajaxUrl,
                        type: 'POST',
                        timeout: 30000,
                        data: {
                            action: 'autoblogger_generate_post_from_interview',
                            nonce: autobloggerData.nonce,
                            interview_id: interviewId
                        },
                        success: function(genResponse) {
                            if (genResponse.success) {
                                $status.html('<div class="notice notice-info inline"><p><?php esc_html_e('Generation started. Monitoring progress...', 'autoblogger'); ?></p></div>');
                                $button.text('<?php esc_html_e('Generating...', 'autoblogger'); ?>');
                                
                                // Start polling for status
                                startViewScriptPolling(interviewId, $status, $button, originalText);
                            } else {
                                $status.html('<div class="notice notice-error inline"><p><?php esc_html_e('Failed to start generation: ', 'autoblogger'); ?>' + (genResponse.data.message || '<?php esc_html_e('Unknown error', 'autoblogger'); ?>') + '</p></div>');
                                $button.prop('disabled', false).text(originalText);
                            }
                        },
                        error: function() {
                            $status.html('<div class="notice notice-error inline"><p><?php esc_html_e('Failed to start generation. Please try again.', 'autoblogger'); ?></p></div>');
                            $button.prop('disabled', false).text(originalText);
                        }
                    });
                } else {
                    $status.html('<div class="notice notice-error inline"><p>' + response.data.message + '</p></div>');
                    $button.prop('disabled', false).text(originalText);
                }
            },
            error: function(xhr, status, error) {
                let errorMsg = '<?php esc_html_e('Failed to update settings.', 'autoblogger'); ?>';
                if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    errorMsg = xhr.responseJSON.data.message;
                }
                $status.html('<div class="notice notice-error inline"><p>' + errorMsg + '</p></div>');
                $button.prop('disabled', false).text(originalText);
            }
        });
        } // End submitUpdate function
    });

    // Load interview data
    function loadInterview() {
        $.ajax({
            url: autobloggerData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'autoblogger_get_interview',
                nonce: autobloggerData.nonce,
                interview_id: interviewId
            },
            success: function(response) {
                $loading.hide();
                
                if (response.success) {
                    currentInterview = response.data.interview;
                    populateEditForm(currentInterview);
                    
                    // Show Create WordPress Draft button if post exists
                    const postId = currentInterview.associatedPostId?._id || currentInterview.associatedPostId?.id || currentInterview.associatedPostId || null;
                    if (postId) {
                        $('#create-wp-draft-btn').data('post-id', postId).show();
                    } else {
                        $('#create-wp-draft-btn').hide();
                    }
                    
                    $container.show();
                } else {
                    $error.html('<div class="notice notice-error"><p>' + response.data.message + '</p></div>');
                    $error.show();
                }
            },
            error: function() {
                $loading.hide();
                $error.html('<div class="notice notice-error"><p><?php esc_html_e('Failed to load interview. Please try again.', 'autoblogger'); ?></p></div>');
                $error.show();
            }
        });
    }

    // Handle Create WordPress Draft button click
    $('#create-wp-draft-btn').on('click', function() {
        const $button = $(this);
        const postId = $button.data('post-id');
        const originalText = $button.text();
        
        if (!postId) {
            alert('<?php esc_html_e('Post ID not found', 'autoblogger'); ?>');
            return;
        }
        
        $button.prop('disabled', true).text('<?php esc_html_e('Creating...', 'autoblogger'); ?>');
        
        $.ajax({
            url: autobloggerData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'autoblogger_create_wp_draft',
                nonce: autobloggerData.nonce,
                post_id: postId
            },
            success: function(response) {
                if (response.success) {
                    alert('<?php esc_html_e('WordPress draft created successfully! Redirecting...', 'autoblogger'); ?>');
                    if (response.data.edit_url) {
                        window.location.href = response.data.edit_url;
                    } else {
                        $button.prop('disabled', false).text(originalText);
                    }
                } else {
                    alert('<?php esc_html_e('Failed to create WordPress draft: ', 'autoblogger'); ?>' + (response.data.message || '<?php esc_html_e('Unknown error', 'autoblogger'); ?>'));
                    $button.prop('disabled', false).text(originalText);
                }
            },
            error: function() {
                alert('<?php esc_html_e('Failed to create WordPress draft. Please try again.', 'autoblogger'); ?>');
                $button.prop('disabled', false).text(originalText);
            }
        });
    });

    // Polling functions for view script page
    let viewScriptPollingInterval = null;
    let viewScriptPollingStartTime = null;
    const VIEW_SCRIPT_MAX_POLLING_TIME = 15 * 60 * 1000; // 15 minutes
    const VIEW_SCRIPT_POLLING_INTERVAL = 3000; // 3 seconds
    
    function startViewScriptPolling(interviewId, $status, $button, originalText) {
        console.log('=== Starting view script polling ===');
        viewScriptPollingStartTime = Date.now();
        
        // Clear any existing interval
        if (viewScriptPollingInterval) {
            clearInterval(viewScriptPollingInterval);
        }
        
        // Poll immediately, then every 3 seconds
        pollViewScriptStatus(interviewId, $status, $button, originalText);
        viewScriptPollingInterval = setInterval(function() {
            pollViewScriptStatus(interviewId, $status, $button, originalText);
        }, VIEW_SCRIPT_POLLING_INTERVAL);
    }
    
    function stopViewScriptPolling() {
        if (viewScriptPollingInterval) {
            clearInterval(viewScriptPollingInterval);
            viewScriptPollingInterval = null;
        }
    }
    
    function pollViewScriptStatus(interviewId, $status, $button, originalText) {
        // Check if we've exceeded maximum polling time
        const elapsedTime = Date.now() - viewScriptPollingStartTime;
        if (elapsedTime > VIEW_SCRIPT_MAX_POLLING_TIME) {
            console.log('Max polling time exceeded');
            stopViewScriptPolling();
            $status.html('<div class="notice notice-error inline"><p><?php esc_html_e('Generation timeout: The process is taking longer than expected. Please try again later.', 'autoblogger'); ?></p></div>');
            $button.prop('disabled', false).text(originalText);
            return;
        }
        
        $.ajax({
            url: autobloggerData.ajaxUrl,
            type: 'POST',
            timeout: 10000,
            data: {
                action: 'autoblogger_get_generation_status',
                nonce: autobloggerData.nonce,
                interview_id: interviewId
            },
            success: function(response) {
                if (response.success && response.data && response.data.status) {
                    const statusData = response.data.status;
                    console.log('Status update:', statusData);
                    
                    const progress = statusData.progress || 0;
                    const statusLabel = statusData.statusLabel || '<?php esc_html_e('Processing...', 'autoblogger'); ?>';
                    const status = statusData.status;
                    
                    // Update status display
                    let progressText = '';
                    if (progress > 0) {
                        progressText = ' (' + Math.round(progress) + '%)';
                    }
                    $status.html('<div class="notice notice-info inline"><p>' + statusLabel + progressText + '</p></div>');
                    $button.text('<?php esc_html_e('Generating...', 'autoblogger'); ?>' + progressText);
                    
                    // Check if generation is complete
                    if (status === 'COMPLETED') {
                        stopViewScriptPolling();
                        handleViewScriptComplete(interviewId, $status, $button, originalText);
                    } else if (status === 'FAILED') {
                        stopViewScriptPolling();
                        $status.html('<div class="notice notice-error inline"><p><?php esc_html_e('Generation failed: ', 'autoblogger'); ?>' + statusLabel + '</p></div>');
                        $button.prop('disabled', false).text(originalText);
                    } else if (status === 'CANCELLED') {
                        stopViewScriptPolling();
                        $status.html('<div class="notice notice-warning inline"><p><?php esc_html_e('Generation was cancelled: ', 'autoblogger'); ?>' + statusLabel + '</p></div>');
                        $button.prop('disabled', false).text(originalText);
                    }
                    // Continue polling for IN_PROGRESS or NOT_STARTED
                } else {
                    console.error('Invalid status response:', response);
                }
            },
            error: function(xhr, status, error) {
                console.error('Status polling error:', error);
                // Don't stop polling on error, just log it
            }
        });
    }
    
    function handleViewScriptComplete(interviewId, $status, $button, originalText) {
        console.log('=== View Script Generation Complete ===');
        
        $status.html('<div class="notice notice-success inline"><p><?php esc_html_e('Generation completed! Fetching post...', 'autoblogger'); ?></p></div>');
        
        // Get the generated post and create WordPress draft
        $.ajax({
            url: autobloggerData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'autoblogger_get_interview',
                nonce: autobloggerData.nonce,
                interview_id: interviewId
            },
            success: function(response) {
                if (response.success && response.data && response.data.interview && response.data.interview.associatedPostId) {
                    const postId = response.data.interview.associatedPostId;
                    console.log('Post ID:', postId);
                    
                    // Create WordPress draft
                    $status.html('<div class="notice notice-success inline"><p><?php esc_html_e('Creating WordPress draft...', 'autoblogger'); ?></p></div>');
                    
                    $.ajax({
                        url: autobloggerData.ajaxUrl,
                        type: 'POST',
                        data: {
                            action: 'autoblogger_create_wp_draft',
                            nonce: autobloggerData.nonce,
                            post_id: postId
                        },
                        success: function(draftResponse) {
                            if (draftResponse.success) {
                                $status.html('<div class="notice notice-success inline"><p><?php esc_html_e('WordPress draft created successfully! Redirecting...', 'autoblogger'); ?></p></div>');
                                setTimeout(function() {
                                    window.location.href = draftResponse.data.edit_url;
                                }, 1000);
                            } else {
                                $status.html('<div class="notice notice-warning inline"><p><?php esc_html_e('Post generated but draft creation failed: ', 'autoblogger'); ?>' + (draftResponse.data.message || '<?php esc_html_e('Unknown error', 'autoblogger'); ?>') + '</p></div>');
                                $button.prop('disabled', false).text(originalText);
                            }
                        },
                        error: function() {
                            $status.html('<div class="notice notice-warning inline"><p><?php esc_html_e('Post generated but failed to create WordPress draft.', 'autoblogger'); ?></p></div>');
                            $button.prop('disabled', false).text(originalText);
                        }
                    });
                } else {
                    $status.html('<div class="notice notice-warning inline"><p><?php esc_html_e('Post generated but could not retrieve post ID. Please check the drafts list.', 'autoblogger'); ?></p></div>');
                    $button.prop('disabled', false).text(originalText);
                }
            },
            error: function() {
                $status.html('<div class="notice notice-warning inline"><p><?php esc_html_e('Post generated but failed to retrieve details. Please check the drafts list.', 'autoblogger'); ?></p></div>');
                $button.prop('disabled', false).text(originalText);
            }
        });
    }

    // Load interview on page load
    loadInterview();
});
</script>
